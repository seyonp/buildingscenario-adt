using System;
using System.IO;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using Azure.Identity;
using Azure.DigitalTwins.Core;
using Azure.Core.Pipeline;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Azure;
using System.Threading.Tasks;


namespace DataIngestor
{
    //https://docs.microsoft.com/en-us/azure/digital-twins/how-to-authenticate-client#write-application-code
    //https://docs.microsoft.com/en-us/azure/digital-twins/how-to-ingest-iot-hub-data?tabs=cli#create-a-function

    public static class StorageToADTFunction
    {
        private static readonly string adtInstanceUrl = Environment.GetEnvironmentVariable("ADT_SERVICE_URL");
        private static readonly HttpClient httpClient = new HttpClient();

        [FunctionName("StorageToADTFunction")]
        public static async Task RunAsync([BlobTrigger("inputtest/{name}", Connection = "DefaultEndpointsProtocol=https;AccountName=adlsstoragetest1013;AccountKey=sXOvUnMCO2xNF56caXQvIJwExG84WQ88PtK4pLIGbk8cydwSiHRSSQjK8ZTGryRYccj+t6qncBbD+AStFGe09g==;EndpointSuffix=core.windows.net")] Stream inputBlob,
            string name,
            ILogger log)
        {

            if (adtInstanceUrl == null) log.LogError("Application setting \"ADT_SERVICE_URL\" not set");

            try
            {
                // Authenticate with Digital Twins
                var cred = new ManagedIdentityCredential("https://digitaltwins.azure.net");
                var client = new DigitalTwinsClient(
                    new Uri(adtInstanceUrl),
                    cred,
                    new DigitalTwinsClientOptions { Transport = new HttpClientTransport(httpClient) });
                log.LogInformation($"ADT service client connection created.");

                // If there is a event grid event:
                using (var reader = new StreamReader(inputBlob))
                {

                    var line = reader.ReadLine();
                    var headers = line.Split(',');

                    while (!reader.EndOfStream)
                    {
                        line = reader.ReadLine();
                        var values = line.Split(',');

                        // for (int i = 0; i < (values.Length - 1); i++)
                        // {
                        string deviceId = (string)values[0];
                        double temperature = Convert.ToDouble(values[1]);
                        double humidity = Convert.ToDouble(values[2]);
                        // }

                        // <Update_twin_in_ADT>
                        var updateTwinData = new JsonPatchDocument();

                        updateTwinData.AppendReplace("/temperature", temperature);
                        updateTwinData.AppendReplace("/humidity", humidity);

                        await client.UpdateDigitalTwinAsync(deviceId, updateTwinData);
                    }

                    // <Find_device_ID_and_temperature>
                    // JObject deviceMessage = (JObject)JsonConvert.DeserializeObject(eventGridEvent.Data.ToString());
                    // string deviceId = (string)deviceMessage["systemProperties"]["iothub-connection-device-id"];
                    // var temperature = deviceMessage["body"]["temperature"];
                    // var temperatureAlert = deviceMessage["body"]["temperatureAlert"];

                    // log.LogInformation($"Device:{deviceId} Temperature is:{temperature}, Temp Alert is: {temperatureAlert}");

                }
            }
            catch (Exception ex)
            {
                log.LogError($"Error in ingest function: {ex.Message}");
            }
        }
    }
}