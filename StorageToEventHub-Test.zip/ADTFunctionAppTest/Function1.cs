using System;
using System.IO;
using System.Threading.Tasks;
using Azure.Core.Pipeline;
using Azure.Identity;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Azure;
using Azure.DigitalTwins.Core;
using static System.Net.WebRequestMethods;

namespace ADTFunctionAppTest
{
    public static class PushRawDataToEventHub
    {
        //new lines
        //private static readonly string adtInstanceUrl = "https://sctc-test-adt.api.sea.digitaltwins.azure.net"; //Environment.GetEnvironmentVariable("ADT_SERVICE_URL");
        //private static readonly HttpClient httpClient = new HttpClient();

        [FunctionName("PushRawDataToEventHub")]
        public static async Task Run([BlobTrigger("raw-data-storage/{name}", Connection = "rawDataStorage")]Stream myBlob,
            [EventHub("pushrawdata", Connection = "EventHubConnectionAppSetting")] IAsyncCollector<string> outputEvents,
            string name, 
            ILogger log)
        {
            log.LogInformation($"C# Blob trigger function Processed blob\n Name:{name} \n Size: {myBlob.Length} Bytes");
            
            //if (adtInstanceUrl == null) log.LogError("Application setting \"ADT_SERVICE_URL\" not set");

            try
            {
                // Authenticate with Digital Twins
                //var cred = new ManagedIdentityCredential("https://digitaltwins.azure.net");
                //var client = new DigitalTwinsClient(
                //    new Uri(adtInstanceUrl),
                //    cred,
                //    new DigitalTwinsClientOptions { Transport = new HttpClientTransport(httpClient) });
                //log.LogInformation($"ADT service client connection created.");

                using (var reader = new StreamReader(myBlob))
                {
                    //Read the first line of the CSV file and break into header values
                    var line = reader.ReadLine();
                    log.LogInformation("headers: " + line);
                    var headers = line.Split(',');
                    //log.LogInformation("headers: " + line);
                    while (!reader.EndOfStream)
                    {
                        string outputJSON = "";
                        outputJSON = outputJSON + "{\n";

                        //Read our lines one by one and split into values
                        line = reader.ReadLine();
                        var values = line.Split(',');
                        log.LogInformation("Values: " + line);

                        for (int i = 0; i < (values.Length - 1); i++)
                        {
                            outputJSON = outputJSON + "  \"" + headers[i] + "\": \"" + values[i] + "\",\n";
                        }
                        int j = values.Length - 1;
                        outputJSON = outputJSON + "  \"" + headers[j] + "\": \"" + values[j] + "\"\n";
                        //Close the JSON
                        outputJSON = outputJSON + "}";

                        JObject deviceMessage = (JObject)JsonConvert.DeserializeObject(outputJSON);

                        await outputEvents.AddAsync(outputJSON);

                        // <Find_device_ID_and_temperature>
                        //var rawDeviceId = deviceMessage["deviceid"];
                        //var rawTemperature = deviceMessage["temperature"];
                        //var rawHumidity = deviceMessage["humidity"];

                        //string deviceId = Convert.ToString(rawDeviceId);
                        //double temperature = Convert.ToDouble(rawTemperature);
                        //double humidity = Convert.ToDouble(rawHumidity);

                        //log.LogInformation($"Device:{deviceId}, Temperature is:{temperature}, Humidity is: {humidity}");

                        // <Update_twin_with_device_temperature>
                        //var updateTwinData = new JsonPatchDocument();

                        //updateTwinData.AppendReplace("/temperature", temperature);
                        //updateTwinData.AppendReplace("/humidity", humidity);

                        //await client.UpdateDigitalTwinAsync(deviceId, updateTwinData);
                        log.LogInformation("Updated: " + outputJSON);
                    }
                }
            }

            catch (Exception ex)
            {
                log.LogError($"Error in ingest function: {ex.Message}");
            }
        }
    }
}
