using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Azure.Core.Pipeline;
using Azure.Identity;
//using Azure.Messaging.EventHubs;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Net.Http;
using Azure.DigitalTwins.Core;
using Azure;
using Microsoft.Azure.EventHubs;

namespace EventHubToADT
{
    public static class EventHubToADTFunction
    {
        private static readonly string adtInstanceUrl = Environment.GetEnvironmentVariable("ADT_SERVICE_URL"); // "https://sctc-test-adt.api.sea.digitaltwins.azure.net";
        private static readonly HttpClient httpClient = new HttpClient();

        [FunctionName("EventHubToADTFunction")]
        public static async Task RunAsync([EventHubTrigger("pushrawdata", Connection="eventHubConnectionString")] EventData[] events, ILogger log)
        {
            if (adtInstanceUrl == null) log.LogError("Application setting \"ADT_SERVICE_URL\" not set");

            // Authenticate with Digital Twins
            var cred = new ManagedIdentityCredential("https://digitaltwins.azure.net");
            var client = new DigitalTwinsClient(
                new Uri(adtInstanceUrl),
                cred,
                new DigitalTwinsClientOptions { Transport = new HttpClientTransport(httpClient) });
            log.LogInformation($"ADT service client connection created.");

            var exceptions = new List<Exception>();

            foreach (EventData eventData in events)
            {
                try
                {
                    // Replace these two lines with your processing logic.
                    
                    string messageBody = Encoding.UTF8.GetString(eventData.Body);
                    JObject deviceMessage = (JObject)JsonConvert.DeserializeObject(messageBody);
                    log.LogInformation($"C# Event Hub trigger function processed a message: {messageBody}");

                    // <Find_device_ID_and_temperature>
                    var rawDeviceId = deviceMessage["deviceid"];
                    var rawTemperature = deviceMessage["temperature"];
                    var rawHumidity = deviceMessage["humidity"];

                    string deviceId = Convert.ToString(rawDeviceId);
                    var temperature = rawTemperature;
                    var humidity = rawHumidity;

                    log.LogInformation($"Device: {deviceId}, Temperature is: {temperature}, Humidity is: {humidity}");

                    // <Update_twin_with_device_temperature>
                    var updateTwinData = new JsonPatchDocument();

                    updateTwinData.AppendReplace("/temperature", temperature.Value<double>());
                    updateTwinData.AppendReplace("/humidity", humidity.Value<double>());
                    //updateTwinData.AppendReplace("/temperature", temperature.Value<double>());
                    //updateTwinData.AppendReplace("/temperatureAlert", temperatureAlert.Value<bool>());

                    await client.UpdateDigitalTwinAsync(deviceId, updateTwinData);

                    await Task.Yield();
                }

                catch (Exception e)
                {
                    // We need to keep processing the rest of the batch - capture this exception and continue.
                    // Also, consider capturing details of the message that failed processing so it can be processed again later.
                    exceptions.Add(e);
                }
            }

            // Once processing of the batch is complete, if any messages in the batch failed processing throw an exception so that there is a record of the failure.

            if (exceptions.Count > 1)
                throw new AggregateException(exceptions);

            if (exceptions.Count == 1)
                throw exceptions.Single();

        }
    }
}
