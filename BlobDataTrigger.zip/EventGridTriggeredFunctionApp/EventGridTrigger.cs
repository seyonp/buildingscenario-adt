// Default URL for triggering event grid function in the local environment.
// http://localhost:7071/runtime/webhooks/EventGrid?functionName={functionname}
using System;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Host;
using Microsoft.Azure.EventGrid.Models;
using Microsoft.Azure.WebJobs.Extensions.EventGrid;
using Microsoft.Extensions.Logging;
using System.Net.Http;
using Azure.Identity;
using Azure.DigitalTwins.Core;
using Azure.Core.Pipeline;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using Azure;
using System.Threading.Tasks;
using System.IO;
using BlobData;
using System.Net;

namespace DataIngestor
{
    //https://docs.microsoft.com/en-us/azure/digital-twins/how-to-authenticate-client#write-application-code
    //https://docs.microsoft.com/en-us/azure/digital-twins/how-to-ingest-iot-hub-data?tabs=cli#create-a-function

    public static class IoTHubToAzureDataTwinsFunction
    {
        private static readonly string adtInstanceUrl = Environment.GetEnvironmentVariable("ADT_SERVICE_URL");
        private static readonly HttpClient httpClient = new HttpClient();

        [FunctionName("IoTHubToADTFunction")]
        public static async Task RunAsync([EventGridTrigger] EventGridEvent eventGridEvent, ILogger log)
        {
            log.LogInformation(eventGridEvent.Data.ToString());

            if (adtInstanceUrl == null) log.LogError("Application setting \"ADT_SERVICE_URL\" not set");

            try
            {
                // Authenticate with Digital Twins
                var cred = new ManagedIdentityCredential("https://digitaltwins.azure.net");
                var client = new DigitalTwinsClient(
                    new Uri(adtInstanceUrl),
                    cred,
                    new DigitalTwinsClientOptions { Transport = new HttpClientTransport(httpClient) });
                log.LogInformation($"ADT service client connection created.");

                // If there is a event grid event:
                if (eventGridEvent != null && eventGridEvent.Data != null)
                {

                    var blobEvent = JsonConvert.DeserializeObject<BlobEventData>(eventGridEvent.Data.ToString());
                    //log.LogInformation(eventGridEvent.Data.ToString());

                    if (blobEvent == null)
                    {
                        log.LogError("Could not parse blob event data from EventGrid event.");
                        throw new Exception("Could not parse blob event data from EventGrid event.");
                    }

                    var fileUri = new Uri(blobEvent.Url);
                    string fileName;
                    fileName = WebUtility.UrlDecode(Path.GetFileName(fileUri.AbsolutePath));

                    // <Find_device_ID_and_temperature>
                    JObject deviceMessage = (JObject)JsonConvert.DeserializeObject(eventGridEvent.Data.ToString());

                    var rawDeviceId = deviceMessage["deviceid"];
                    var rawTemperature = deviceMessage["temperature"];
                    var rawHumidity = deviceMessage["humidity"];

                    string deviceId = Convert.ToString(rawDeviceId);
                    double temperature = Convert.ToDouble(rawTemperature);
                    double humidity = Convert.ToDouble(rawHumidity);

                    log.LogInformation($"Device:{deviceId} Temperature is:{temperature}, Humidity is: {humidity}");

                    // <Update_twin_in_ADT>
                    var updateTwinData = new JsonPatchDocument();

                    //updateTwinData.AppendReplace("/temperature", temperature.Value<double>());
                    updateTwinData.AppendReplace("/temperature", temperature);
                    updateTwinData.AppendReplace("/humidity", humidity);

                    await client.UpdateDigitalTwinAsync(deviceId, updateTwinData);

                }
            }
            catch (Exception ex)
            {
                log.LogError($"Error in ingest function: {ex.Message}");
            }
        }
    }
}
