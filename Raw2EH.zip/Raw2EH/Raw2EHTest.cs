using System;
using System.IO;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Azure.WebJobs;
using Microsoft.Azure.WebJobs.Extensions.Http;
using Microsoft.AspNetCore.Http;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Linq;
using System.Reflection.Metadata;

namespace Raw2EH
{
    public static class Raw2EHTest
    {
        [FunctionName("Raw2EHTest")]
        public static async Task<IActionResult> Run(
            [HttpTrigger(AuthorizationLevel.Function, "get", "post", Route = null)] HttpRequest req,
            [EventHub("tempdatahub", Connection = "EventHubConnectionAppSetting")] IAsyncCollector<string> outputEvents,
            ILogger log)
        {
            log.LogInformation("C# HTTP trigger function processed a request.");

            //string name = req.Query["name"];

            string requestBody = await new StreamReader(req.Body).ReadToEndAsync();
            dynamic data = JsonConvert.DeserializeObject(requestBody);

            //Send device message to Event Hub
            await outputEvents.AddAsync(requestBody);
            //name = name ?? data?.name;

            string responseMessage = default;
            ObjectResult result;

            if (string.IsNullOrEmpty(requestBody))
            {
                responseMessage = "Please provide the request body.";
                result = new BadRequestObjectResult(responseMessage);
            }
            else
            {
                responseMessage = "This HTTP triggered function executed successfully.";
                result = new OkObjectResult(responseMessage);
            }
            //string responseMessage = string.IsNullOrEmpty(requestBody)
            //   ? "Please provide the request body."
            //   : $"Hello, {name}. This HTTP triggered function executed successfully.";

            return result;
        }
    }
}
